﻿using Microsoft.AspNetCore.Components.Forms;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MVC6Crud.Common;
using MVC6Crud.Data;
using MVC6Crud.Models;
using MVC6Crud.ViewModel;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace MVC6Crud.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;

        private readonly IConfiguration _configuration;
        public ProductController(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            List<ResumeListViewModel> resumeListViewModel = new List<ResumeListViewModel>();
            return View(resumeListViewModel);
        }

        public IActionResult Create()
        {
            ProfileViewModel productCreateViewModel = new ProfileViewModel();
            return View(productCreateViewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Create(ProfileViewModel profileViewModel)
        {
            ResumeListViewModel resumeListViewModel = await MatchTopProfile(profileViewModel);

            return View("Index", resumeListViewModel);

        }

        public IActionResult MatchResume()
        {
            return View();
        }

        public async Task<IActionResult> Result(IFormFile con)
        {
            var _projectId = _configuration.GetValue<string>("GoogleCloud:projectId");
            var _region = _configuration.GetValue<string>("GoogleCloud:region");
            var _endpointName = _configuration.GetValue<string>("GoogleCloud:endpointName");
            var _token = _configuration.GetValue<string>("GoogleCloud:token");
            string url = $"https://{_region}-aiplatform.googleapis.com/v1/projects/{_projectId}/locations/{_region}/endpoints/{_endpointName}:predict";

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
                var res = con.FileToText();
                if (res == null)
                {
                    return View(new PredictionResult());
                }
                // Define the request body
                var requestBody = new RequestBody()
                {
                    instances = new[]
                    {
                new Instance{
                    content = res.ToString()
                }
            }
                };

                // Serialize the request body to JSON
                var json = JsonConvert.SerializeObject(requestBody);
                // string json = JsonConvert.SerializeObject(inputData);
                HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PostAsync(url, content);

                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    RootObject responseBody = JsonConvert.DeserializeObject<RootObject>(result);
                    var combined = new List<PredictionResult>();
                    for (var i = 0; i < responseBody.Predictions[0].Confidences.Count; i++)
                    {
                        combined.Add(new PredictionResult() { Confidence = responseBody.Predictions[0].Confidences[i], DisplayName = responseBody.Predictions[0].DisplayNames[i], Id = responseBody.Predictions[0].Ids[i] });
                    }
                    var resu = combined.OrderByDescending(x => x.Confidence).First();
                    return View(resu);
                }
                else
                {
                    return View(new PredictionResult());
                }
            }
        }

        [HttpPost]
        [Route("api/SearchProfile")]
        public async Task<IActionResult> SearchProfile([FromBody] ProfileViewModel profileViewModel)
        {
            ResumeListViewModel resumeListViewModel = await MatchTopProfile(profileViewModel);
            resumeListViewModel.Count = resumeListViewModel.Results.Count;
            return Ok(resumeListViewModel);

        }

        #region private methods

        private async Task<ResumeListViewModel> MatchTopProfile(ProfileViewModel profileViewModel)
        {
            string baseUrlOfGcpBucket = "https://storage.googleapis.com/";
            //string baseUrlOfGcpBucket = profileViewModel.InputPath + "/" + profileViewModel?.InputPathPrefix;
            var _projectId = _configuration.GetValue<string>("GoogleCloud:projectId");
            var _region = _configuration.GetValue<string>("GoogleCloud:region");
            var _endpointName = _configuration.GetValue<string>("GoogleCloud:endpointName");
            var _token = _configuration.GetValue<string>("GoogleCloud:token");
            string url = $"https://{_region}-aiplatform.googleapis.com/v1/projects/{_projectId}/locations/{_region}/endpoints/{_endpointName}:predict";

            var profileTypes = await GetBestProfileMatchType(profileViewModel, _token, url);
            var processedProfileResults = await ProcessResumeForBestMatch(_token, url, profileViewModel.InputPath, profileViewModel.InputPathPrefix);

            List<ProfileResult> bestMatch = new List<ProfileResult>();
            foreach (var profileType in profileTypes)
            {
                var pResult = processedProfileResults.Where(x => x.ProfileType == profileType.DisplayName);//.Take(profileViewModel.NoOfMatches)
                bestMatch.AddRange(pResult);
            }
            bestMatch = bestMatch.OrderByDescending(x => x.Confidence).Take(profileViewModel.NoOfMatches).ToList();

            ResumeListViewModel resumeListViewModel = new ResumeListViewModel();
            resumeListViewModel.Results = new List<ResumeViewModel>();
            resumeListViewModel.Status = "success";
            resumeListViewModel.Metadata = new ProfileMetadataViewModel { ConfidenceScore = bestMatch.OrderByDescending(x => x.Confidence).FirstOrDefault()?.Confidence };

            foreach (var item in bestMatch)
            {
                resumeListViewModel.Results.Add(new ResumeViewModel { FileName = item.FileName, FileUrl = baseUrlOfGcpBucket + item.FileName, ProfileType = item.ProfileType, Score = item.Confidence });
            }

            return resumeListViewModel;
        }

        private async Task<List<PredictionResult>> GetBestProfileMatchType(ProfileViewModel productCreateViewModel, string _token, string url)
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
                var res = productCreateViewModel.Context;
                if (res == null)
                {
                    return new List<PredictionResult>();
                }
                // Define the request body
                var requestBody = new RequestBody()
                {
                    instances = new[]
                    {
                new Instance{
                    content = res.ToString()
                }
                    }
                };

                // Serialize the request body to JSON
                var json = JsonConvert.SerializeObject(requestBody);
                // string json = JsonConvert.SerializeObject(inputData);
                HttpContent content = new StringContent(json, Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PostAsync(url, content);

                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    RootObject responseBody = JsonConvert.DeserializeObject<RootObject>(result);
                    var combined = new List<PredictionResult>();
                    for (var i = 0; i < responseBody.Predictions[0].Confidences.Count; i++)
                    {
                        combined.Add(new PredictionResult() { Confidence = responseBody.Predictions[0].Confidences[i], DisplayName = responseBody.Predictions[0].DisplayNames[i], Id = responseBody.Predictions[0].Ids[i] });
                    }
                    return combined.OrderByDescending(x => x.Confidence).Where(s => s.Confidence > 0.5).ToList();
                }
                else
                {
                    return new List<PredictionResult>();
                }
            }
        }


        private async Task<List<ProfileResult>> ProcessResumeForBestMatch(string _token, string url, string baseUrlOfGcpBucket, string inputPathPrefix)
        {
            //string baseUrlOfGcpBucket = "https://www.googleapis.com/auth/cloud-platform";
            //string baseUrlOfGcpBucket = "https://storage.googleapis.com/hackathon1415";
            //string baseUrlOfGcpBucket = "https://console.cloud.google.com/storage/browser/hackathon1415";
            // string baseUrlOfGcpBucket = "https://console.cloud.google.com/storage/browser/hackathontestdata2024";
            var profiles = Utils.GetFiles(baseUrlOfGcpBucket, inputPathPrefix);

            foreach (var item in profiles)
            {
                ProfileViewModel productViewModel = new ProfileViewModel { Context = item.FileText };
                var profileType = await GetBestProfileMatchType(productViewModel, _token, url);

                foreach (var p in profileType)
                {
                    item.ProfileType = profileType.First().DisplayName;
                    item.Confidence = profileType.First().Confidence;
                };
            }
            return profiles;
        }

        #endregion

    }
}
