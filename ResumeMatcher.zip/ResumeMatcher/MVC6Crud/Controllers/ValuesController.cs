﻿//using Microsoft.AspNetCore.Mvc;
//using MVC6Crud.Controllers;
//using MVC6Crud.Data;
//using MVC6Crud.ViewModel;

//// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

//namespace ResumeMatcherAI.Web.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ValuesController : ControllerBase
//    {
//        private readonly ApplicationDbContext _context;

//        private readonly IConfiguration _configuration;
//        public ValuesController(ApplicationDbContext context, IConfiguration configuration)
//        {
//            _context = context;
//            _configuration = configuration;
//        }
//        // GET: api/<ValuesController>
//        [HttpGet]
//        public IEnumerable<string> Get()
//        {
//            return new string[] { "value1", "value2" };
//        }

//        // GET api/<ValuesController>/5
//        [HttpGet("{id}")]
//        public string Get(int id)
//        {
//            return "value";
//        }

//        // POST api/<ValuesController>
//        [HttpPost]
//        public ActionResult Post([FromBody] ProfileViewModel profileViewModel)
//        {
//            string baseUrlOfGcpBucket = "https://storage.googleapis.com/";
//            //ProfileViewModel profileViewModel = new ProfileViewModel
//            //{
//            //    Category = category,
//            //    Context = context,
//            //    InputPath = inputPath,
//            //    InputPathPrefix = inputPathPrefix,
//            //    NoOfMatches = int.Parse(noOfMatches),
//            //    Threshold = double.Parse(threshold)
//            //};
//            //string baseUrlOfGcpBucket = profileViewModel.InputPath + "/" + profileViewModel?.InputPathPrefix;
//            var _projectId = _configuration.GetValue<string>("GoogleCloud:projectId");
//            var _region = _configuration.GetValue<string>("GoogleCloud:region");
//            var _endpointName = _configuration.GetValue<string>("GoogleCloud:endpointName");
//            var _token = _configuration.GetValue<string>("GoogleCloud:token");
//            string url = $"https://{_region}-aiplatform.googleapis.com/v1/projects/{_projectId}/locations/{_region}/endpoints/{_endpointName}:predict";

//            var ctrlObj = new ProductController(_context, _configuration);

//            Task<MVC6Crud.Models.PredictionResult> profileType =  ctrlObj.GetBestProfileMatchType(profileViewModel, _token, url);
//            var processedProfileResults = ctrlObj.ProcessResumeForBestMatch(_token, url, profileViewModel.InputPath, profileViewModel.InputPathPrefix);

//            var bestMatch = processedProfileResults.Result.Where(x => x.ProfileType == profileType.Result.DisplayName).Take(profileViewModel.NoOfMatches);

//            ResumeListViewModel resumeListViewModel = new ResumeListViewModel();
//            resumeListViewModel.Results = new List<ResumeViewModel>();
//            resumeListViewModel.Status = "success";
//            resumeListViewModel.Metadata = new ProfileMetadataViewModel { ConfidenceScore = bestMatch.OrderByDescending(x => x.Confidence).FirstOrDefault()?.Confidence };

//            foreach (var item in bestMatch)
//            {
//                resumeListViewModel.Results.Add(new ResumeViewModel { FileName = item.FileName, FileUrl = baseUrlOfGcpBucket + item.FileName, ProfileType = item.ProfileType, Score = item.Confidence });
//            }

//            return Ok(resumeListViewModel);
//        }
//        //[HttpPost]
//        //public void Post(string value)
//        //{
//        //}

//        // PUT api/<ValuesController>/5
//        [HttpPut("{id}")]
//        public void Put(int id, [FromBody] string value)
//        {
//        }

//        // DELETE api/<ValuesController>/5
//        [HttpDelete("{id}")]
//        public void Delete(int id)
//        {
//        }
//    }
//}
