﻿namespace MVC6Crud.ViewModel
{
    public class ResumeListViewModel
    {
        public string Status { get; set; }
        public int Count { get; set; }
        public ProfileMetadataViewModel Metadata { get; set; }
        public List<ResumeViewModel> Results { get; set; }
    }

    public class ProfileMetadataViewModel
    {
        public double? ConfidenceScore { get; set; }

    }

    public class ResumeViewModel
    {
        public int Id { get; set; }
        public double Score { get; set; }
        public string? FileUrl { get; set; }
        public string? FileName { get; set; }
        public string? ProfileType { get; set; }

    }

}
