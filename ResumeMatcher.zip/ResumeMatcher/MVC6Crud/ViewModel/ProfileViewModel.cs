﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace MVC6Crud.ViewModel
{
    public class ProfileViewModel
    {
        //public int Id { get; set; }
        [Required]
        public string? Context { get; set; }
        //[Required]
        public string? Category { get; set; }
        [Required]
        public int NoOfMatches { get; set; }
        public double Threshold { get; set; }
        [Required]
        public string InputPath { get; set; }
        //[Required]
        public string? InputPathPrefix { get; set; }
    }
}
