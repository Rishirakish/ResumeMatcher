﻿using Google.Apis.Auth.OAuth2;
using Google.Cloud.Storage.V1;
using MVC6Crud.Models;
using NPOI.XWPF.UserModel;
using System.Text;
using UglyToad.PdfPig;
using UglyToad.PdfPig.Content;
using UglyToad.PdfPig.DocumentLayoutAnalysis.TextExtractor;

namespace MVC6Crud.Common
{
    public static class Utils
    {
        public static StringBuilder FileToText(this IFormFile formFile)
        {
            var fileExtension = System.IO.Path.GetExtension(formFile.FileName).ToLower();
            // Determine the file type based on the extension
            if (fileExtension != null)
            {
                if (fileExtension == ".pdf")
                {
                    return PdfToString(formFile);
                }
                else if (fileExtension == ".doc")
                {
                    return DocToString(formFile);
                }
                else if (fileExtension == ".docx")
                {
                    return DocToString(formFile);
                }
                else if (fileExtension == ".txt")
                {
                    return TxtToString(formFile);
                }
            }
            return null;
        }
        private static StringBuilder TxtToString(IFormFile formFile)
        {

            using (var stream = formFile.OpenReadStream())
            {
                return new StringBuilder(new StreamReader(stream, Encoding.UTF8).ReadToEnd());
            }
        }
        private static StringBuilder DocToString(IFormFile formFile)
        {
            using (var stream = formFile.OpenReadStream())
            {
                var doc = new XWPFDocument(stream);
                StringBuilder sb = new StringBuilder();

                foreach (var paragraph in doc.Paragraphs)
                {
                    sb.AppendLine(paragraph.Text);
                }

                return sb;
            }
        }
        private static StringBuilder PdfToString(IFormFile formFile)
        {
            var text = new StringBuilder();
            using (var pdf = PdfDocument.Open(formFile.OpenReadStream()))
            {
                foreach (var page in pdf.GetPages())
                {
                    var data = ContentOrderTextExtractor.GetText(page);
                    // Either extract based on order in the underlying document with newlines and spaces.
                    text.Append(data);

                    // Or based on grouping letters into words.
                    var otherText = string.Join(" ", page.GetWords());

                    // Or the raw text of the page's content stream.
                    var rawText = page.Text;
                }
                return text;
            }
        }

        public static Dictionary<string, string> PdfToString1(this IFormFile formFile, Dictionary<string, MemoryStream> fileStreamList)
        {
            string text = string.Empty;
            var fileTextList = new Dictionary<string, string>();

            foreach (var fileStream in fileStreamList)
            {
                text = string.Empty;
                using (var pdf = PdfDocument.Open(fileStream.Value))
                {
                    foreach (var page in pdf.GetPages())
                    {
                        var data = ContentOrderTextExtractor.GetText(page);
                        // Either extract based on order in the underlying document with newlines and spaces.
                        text += data;

                        //// Or based on grouping letters into words.
                        //var otherText = string.Join(" ", page.GetWords());

                        //// Or the raw text of the page's content stream.
                        //var rawText = page.Text;
                    }

                    fileTextList.Add(fileStream.Key, text);
                }
            }

            return fileTextList;
        }
        public static Dictionary<string, MemoryStream> GetFileStream(string[] fileList)
        {
            string path = @"C:\Users\rishi\Downloads\buk\";
            string filepath = string.Empty;
            var streamList = new Dictionary<string, MemoryStream>();

            foreach (var fileName in fileList)
            {
                filepath = Path.Combine(path, fileName.Trim());
                streamList.Add(fileName, new MemoryStream(File.ReadAllBytes(filepath)));
            }

            return streamList;

        }

        public static void GenerateCsvFromFileText(Dictionary<string, string> fileTextList)
        {
            var outputFileName = "output.csv";
            string path = @"C:\Users\rishi\Downloads\buk\";
            string csvContent = "fileName,label,text\n";
            foreach (var fileText in fileTextList)
            {
                var index = fileText.Value.IndexOf("\r\n");
                if (index == -1)
                {

                }
                else
                {
                    var label = string.Format("{0},", fileText.Value.Substring(0, fileText.Value.IndexOf("\r\n")));
                    var text = string.Format("\"{0}\"\n", fileText.Value.Replace(",", "").Replace("\r\n", "").Replace("\r\a", "").Replace("\r", "").Replace("\a", "").Replace("\t", ""));
                    if (string.IsNullOrEmpty(label) || string.IsNullOrEmpty(text))
                    {
                    }
                    else
                    {
                        csvContent += fileText.Key + "," + label + text;
                    }
                }

            }
            var outputFilePath = Path.Combine(path, outputFileName);
            File.WriteAllText(outputFilePath, csvContent);
        }


        public static List<ProfileResult> GetFiles(string baseUrlOfGcpBucket, string inputPathPrefix)
        {
            List<ProfileResult> profileResults = new List<ProfileResult>();
            //string bucketName = "hackathon1415";
            var splittextList = baseUrlOfGcpBucket.Split('/');
            string bucketName = splittextList[splittextList.Length-1].Trim();

            // Set up Google Cloud Storage client with service account credentials
            GoogleCredential credential = GoogleCredential.FromFile("aerial-summit-415308-9b403b5e6fbf.json")
                .CreateScoped(baseUrlOfGcpBucket);
            var storageClient = StorageClient.Create(credential);

            int count = 0;

            // List objects in the bucket
            //var objects = storageClient.ListObjects(bucketName, "RESUME/data/");
            var objects = storageClient.ListObjects(bucketName, inputPathPrefix);

            // Iterate over each object in the bucket
            foreach (var storageObject in objects)
            {
                if (count > 20) break;
                count++;
                // Check if the object is a PDF file
                if (storageObject.Name.EndsWith(".pdf"))
                {
                    // Download PDF file from Google Cloud Storage
                    using (var memoryStream = new MemoryStream())
                    {
                        storageClient.DownloadObject(bucketName, storageObject.Name, memoryStream);

                        // Reset position to the beginning of the stream
                        memoryStream.Position = 0;

                        // Load PDF document using PdfPig
                        using (PdfDocument document = PdfDocument.Open(memoryStream))
                        {
                            // Extract text from PDF
                            string textJoined = string.Empty;
                            string firstSentence = string.Empty;
                            List<string> textlist = new List<string>();
                            List<string> fistSentencelist = new List<string>();
                            string text = string.Empty;
                            foreach (Page page in document.GetPages())
                            {
                                var data = ContentOrderTextExtractor.GetText(page);
                                // Either extract based on order in the underlying document with newlines and spaces.
                                text += data;
                            }

                            //var fileNameIndex = storageObject.Name.LastIndexOf('/');
                            //string storageObjectFileName = storageObject.Name.Substring(fileNameIndex+1, storageObject.Name.Length - fileNameIndex-1);
                            profileResults.Add(new ProfileResult { FileName = bucketName + "/" + storageObject.Name, FileText = text });

                        }
                    }
                }
            }
            return profileResults;
        }
    }
}
